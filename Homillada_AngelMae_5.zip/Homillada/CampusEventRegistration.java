import javax.swing.*;

public class CampusEventRegistration extends JFrame {

    public static void main(String[] args) {

        new CampusEventRegistration();
    }


    JTextField nameField;
    JTextField ageField;
    JTextField collegeField;
   
    JComboBox<String> eventBox;

    JRadioButton participant;
    JRadioButton audience;
    JRadioButton faculty;

    JCheckBox pinoy;
    JCheckBox mlbb;
    JCheckBox basket;
    JCheckBox volley;
    JCheckBox database;

    
    JTextArea notesArea;

    
    JButton registerButton;
    JButton clearButton;


    public CampusEventRegistration() {

        setTitle("Campus Event Registration System");
        setSize(600, 650);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JLabel nameLabel = new JLabel("Participant Name:");
        nameLabel.setBounds(30, 30, 150, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(180, 30, 300, 25);
        add(nameField);

        
        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setBounds(30, 70, 150, 25);
        add(ageLabel);

        ageField = new JTextField();
        ageField.setBounds(180, 70, 300, 25);
        add(ageField);

        
        JLabel collegeLabel = new JLabel("College/Department:");
        collegeLabel.setBounds(30, 110, 150, 25);
        add(collegeLabel);

        collegeField = new JTextField();
        collegeField.setBounds(180, 110, 300, 25);
        add(collegeField);

        
        JLabel eventLabel = new JLabel("Event Category:");
        eventLabel.setBounds(30, 150, 150, 25);
        add(eventLabel);

        String events[] = {
            "Select Event",
            "Programming Competition ",
            "Web Design Challenge ",
            "Cybersecurity Seminar ",
            "AI and Emerging Technologies",
            "IT Quiz Bowl "
        };

        eventBox = new JComboBox<>(events);
        eventBox.setBounds(180, 150, 300, 25);
        add(eventBox);

        
        JLabel attendanceLabel = new JLabel("Attendance Type:");
        attendanceLabel.setBounds(30, 190, 150, 25);
        add(attendanceLabel);

        participant = new JRadioButton("Student Participant");
        participant.setBounds(180, 185, 150, 30);
        add(participant);

        audience = new JRadioButton("Student Audience");
        audience.setBounds(330, 185, 140, 30);
        add(audience);

        faculty = new JRadioButton("Faculty/Staff");
        faculty.setBounds(180, 215, 150, 30);
        add(faculty);

        
        ButtonGroup group = new ButtonGroup();
        group.add(participant);
        group.add(audience);
        group.add(faculty);

        
        JLabel workshopLabel = new JLabel("Workshops:");
        workshopLabel.setBounds(30, 260, 150, 25);
        add(workshopLabel);

        pinoy = new JCheckBox("Programming Competition");
        pinoy.setBounds(180, 255, 150, 25);
        add(pinoy);

        mlbb= new JCheckBox("Web Design Challenge");
        mlbb.setBounds(330, 255, 150, 25);
        add(mlbb);

        basket= new JCheckBox("Cybersecurity Seminar");
        basket.setBounds(180, 285, 150, 25);
        add(basket);

        volley= new JCheckBox("AI and Emerging Technologies");
        volley.setBounds(330, 285, 170, 25);
        add(volley);

        database = new JCheckBox("IT Quiz Bowl");
        database.setBounds(180, 315, 180, 25);
        add(database);

        
        JLabel notesLabel = new JLabel("Special Request / Notes:");
        notesLabel.setBounds(30, 355, 160, 25);
        add(notesLabel);

        notesArea = new JTextArea();
        notesArea.setBounds(180, 350, 300, 80);
        add(notesArea);

       
        registerButton = new JButton("REGISTER");
        registerButton.setBounds(180, 460, 130, 35);
        add(registerButton);

    
        clearButton = new JButton("CLEAR");
        clearButton.setBounds(330, 460, 130, 35);
        add(clearButton);


        registerButton.addActionListener(e -> register());

       
        clearButton.addActionListener(e -> clear());
        
        setVisible(true);
    }

    
    public void register() {

        
        if (nameField.getText().equals("")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter your name.");
            return;
        }

        
        if (ageField.getText().equals("")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter your age.");
            return;
        }

        int age;

        try {
            age = Integer.parseInt(ageField.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Age must be a whole number.");
            return;
        }

        if (age <= 0) {
            JOptionPane.showMessageDialog(this,
                    "Age must be greater than zero.");
            return;
        }

       
        if (collegeField.getText().equals("")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter your college or department.");
            return;
        }

       
        if (eventBox.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this,
                    "Please select an event.");
            return;
        }

        if (!participant.isSelected()
                && !audience.isSelected()
                && !faculty.isSelected()) {

            JOptionPane.showMessageDialog(this,
                    "Please select an attendance type.");
            return;
        }

       
        String attendance = "";

        if (participant.isSelected()) {
            attendance = "Student Participant";
        } else if (audience.isSelected()) {
            attendance = "Student Audience";
        } else if (faculty.isSelected()) {
            attendance = "Faculty/Staff";
        }

      
        String workshops = "";

        if (pinoy.isSelected()) {
            workshops = workshops + "Java Programming\n";
        }

        if (mlbb.isSelected()) {
            workshops = workshops + "Web Development\n";
        }

        if (basket.isSelected()) {
            workshops = workshops + "Cybersecurity\n";
        }

        if (volley.isSelected()) {
            workshops = workshops + "Artificial Intelligence\n";
        }

        if (database.isSelected()) {
            workshops = workshops + "Database Management\n";
        }

        if (workshops.equals("")) {
            workshops = "None";
        }

        // Get Notes
        String notes = notesArea.getText();

        if (notes.equals("")) {
            notes = "None";
        }

       
        String summary =
                "REGISTRATION SUCCESSFUL\n\n"
                + "Participant Name: " + nameField.getText() + "\n"
                + "Age: " + age + "\n"
                + "College/Department: " + collegeField.getText() + "\n"
                + "Event Category: " + eventBox.getSelectedItem() + "\n"
                + "Attendance Type: " + attendance + "\n\n"
                + "Workshops:\n" + workshops
                + "\nSpecial Request/Notes:\n" + notes;

        JOptionPane.showMessageDialog(this, summary);
    }

    public void clear() {

        nameField.setText("");
        ageField.setText("");
        collegeField.setText("");

        eventBox.setSelectedIndex(0);

        participant.setSelected(false);
        audience.setSelected(false);
        faculty.setSelected(false);

        pinoy.setSelected(false);
        mlbb.setSelected(false);
        basket.setSelected(false);
        volley.setSelected(false);
        database.setSelected(false);

        notesArea.setText("");
    }

}
